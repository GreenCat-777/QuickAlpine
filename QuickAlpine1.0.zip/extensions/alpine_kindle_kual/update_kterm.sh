#!/bin/sh

/mnt/us/extensions/kterm/bin/kterm -e "bash /mnt/us/extensions/alpine_kindle_kual/update.sh" -k 1 -o U -s 7
