#!/bin/sh

ALPINE_BASE_FOLDER="/mnt/us"

rm $ALPINE_BASE_FOLDER/alpine.ext3
rm $ALPINE_BASE_FOLDER/alpine.sh
rm $ALPINE_BASE_FOLDER/alpine.log
rm $ALPINE_BASE_FOLDER/alpine.conf
rm $ALPINE_BASE_FOLDER/alpine.zip
while [ -f /etc/upstart/alpine.conf ] ; do
	mntroot rw
	sleep 1
	rm /etc/upstart/alpine.conf
	mntroot r
done
echo "Deleted Alpine."
sh press_any_key.sh
